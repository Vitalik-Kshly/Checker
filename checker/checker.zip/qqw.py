import os


if os.system("F") == 1:
    print("ERROR")
else:
    print("OK!!!")
